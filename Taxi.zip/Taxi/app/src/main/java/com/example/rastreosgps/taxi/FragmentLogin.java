package com.example.rastreosgps.taxi;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;

public class FragmentLogin extends Fragment {

 @Nullable
    @Override
    public View onCreateView (@NonNull LayoutInflater inflater, Nullable ViewGroupContainer, @Nullable Bundle savedInstanceState){

     return super.onCreateView(inflater, Container, SavedInstanceState);
 }

}
